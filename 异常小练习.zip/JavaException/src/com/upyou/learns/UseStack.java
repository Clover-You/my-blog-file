package com.upyou.learns;

import com.upyou.learns.practice.Stack;
import com.upyou.learns.practice.Exception.PopStackException;

public class UseStack {
   public static void main(String[] args) {
      // 创建一个栈，默认值5，允许自动扩容
      Stack stack = new Stack(5, true);
      stack.push("压栈");
      try {
         stack.pop();// 弹栈
      } catch (PopStackException e) {
         //TODO: handle exception
         e.printStackTrace();
      }
      for (Object obj : stack.getStack()) {// 查看栈元素
         System.out.println(obj);
      }
   }
}