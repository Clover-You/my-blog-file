package com.upyou.learns.practice.Exception;

public class StackOverflowException
   extends RuntimeException {
   public StackOverflowException() {super();}

   public StackOverflowException(String s) {super(s);}
}