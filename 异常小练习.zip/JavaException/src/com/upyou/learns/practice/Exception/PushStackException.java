package com.upyou.learns.practice.Exception;

public class PushStackException
   extends RuntimeException {
   public PushStackException(){super();}

   public PushStackException(String s) {
      super(s);
   }
}