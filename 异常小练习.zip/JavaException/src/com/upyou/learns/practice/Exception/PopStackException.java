package com.upyou.learns.practice.Exception;

public class PopStackException 
   extends Exception {
   public PopStackException(){super();}

   public PopStackException(String s) {
      super(s);
   }
}