package com.upyou.learns.practice;

import com.upyou.learns.practice.Exception.PopStackException;
import com.upyou.learns.practice.Exception.PushStackException;
import com.upyou.learns.practice.Exception.StackOverflowException;

public class Stack {
   private Object[] elem;
   // Record the number of the stack elements.
   private int nowElemCount;
   // (elem.length - nowElemCount equals 0) will be automatic new an big array.
   private boolean automaticCopy;

   /**
    * The stack default size is 20。
    */
   public Stack() {
      this.elem = new Object[20];
   }
   
   /**
    * Custom the stack size.
    * @param size The Stack size.
    */
   public Stack(int size) {
      this.elem = new Object[size];
   }

   /**
    * Opened automatic copy into an new big array.
    * @param auto off or no automatic copy.
    */
   public Stack(boolean auto) {
      this.automaticCopy = auto;
   }

   /**
    * Setting the stack default size and opened automatic copy into an new big array.
    * @param size The Stack size.
    * @param auto off or no automatic copy.
    */
   public Stack(int size, boolean auto) {
      this.elem = new Object[size];
      this.automaticCopy = auto;
   }

   /**
    * Add an element to the stack.
    * @param arg Element to add.
    * @throws PushStackException
    * @throws StackOverflowException
    */
   public void push(Object arg)
      throws PushStackException, StackOverflowException {
      if (arg == null) {
         throw new PushStackException("Empty elements are not allowed to be pushed!");
      }
      if (elem.length == nowElemCount) {
         if (automaticCopy)
            ensureCapacityInternal();
         else
            throw new StackOverflowException("Exceeds the stack maximum momory!");
      }
      elem[elem.length - nowElemCount - 1] = arg;
      nowElemCount++;
   }

   private void ensureCapacityInternal() {
      if (nowElemCount - elem.length == 0) {
         Object[] newObj = new Object[elem.length + 5];
         System.arraycopy(elem, 0, newObj, 5, elem.length);
         elem = newObj;
      }
   }

   public void pop()
      throws PopStackException{
      if (nowElemCount == 0) {
         throw new PopStackException("Cannot pop because the stack is empty.");
      }
      elem[elem.length - nowElemCount] = null;
      nowElemCount--;
   }

   // Get index of the first empty element.
   public int getNullStack() {
      return elem.length - nowElemCount;
   }

   // Get Stack.
   public Object[] getStack() {
      return this.elem;
   }

   // Get pushed number of.
   public String toString() {
      return String.valueOf(nowElemCount);
   }

}