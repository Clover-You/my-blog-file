package LearnThread;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * TODO
 *
 * @author UpYou
 * @date 2020/11/4 21:10
 */
public class WaitNotifyTest {

    public static void main(String[] args) {
        /**
         * 1。 使用wait和notify方法实现生产者和消费者m模式
         * 2。 什么是生产者和消费者模式？
         *      生产线程负责生产，消费线程负责消费。
         *      生产线程和消费线程要达到均衡
         *      这是一种特殊的业务需求，在这种特殊的情况下需要使用wait和notify方法
         * 3。 wait和notify不是线程对象的方法，是普通java对象的方法。
         * 4。wait和notify方法要建立在线程同步的基础之上。因为多线程要同时操作一个仓库。有线程安全问题。
         * 5。wait方法作用：o.wait(); 让在o对象上活动的线程进入等待。并且释放掉o对象的对象锁。
         * 6。notify方法：唤醒当前在o对象上沉睡的线程。
         * 7。模拟一个仓库：
         *      采用List集合存储
         *      List假设只能存储1个元素
         *      一个元素表示仓库满了，如果List集合中长度为0表示仓库空了。
         *      保证List集合中最多只能存储一个元素。
         */

        // 创建一个仓库
        List list = new ArrayList();
        // 生产者线程
        Thread t1 = new Thread(new Producer(list));
        t1.setName("Producer thread");
        // 将生产线程设置为守护线程
        t1.setDaemon(true);
        // 消费者线程
        Thread t2 = new Thread(new Consumer(list));
        t2.setName("Consumer thread");
        // 启动线程
        t1.start();
        t2.start();

    }
}

/**
 * 生产线程
 */
class Producer implements Runnable {
    /**
     * 仓库
     */
    private List list;

    /**
     * 仓库最大长度
     */
    private final Integer MAX_COUNT = 3;

    public Producer(List list) {
        this.list = list;
    }

    @Override
    public void run() {
        // 因为需要一直生产所以需要使用死循环
        while (true) {
            // 由于仓库是多线程调用，所以有线程安全问题，在守护者线程执行的时候需要将该对象的对象锁剥夺。
            synchronized (list) {
                // 如果大于零，说明仓库里还有数据可消费
                if (list.size() > 0) {
                    try {
                        // 测试wait之后是否会再次抢锁
                        System.out.println("Producer抢锁～");
                        // 使当前线程进入等待状态，并且释放list对象的对象锁。
                        // 如果不释放对象锁，那么当前while一直在执行，每次执行都会将list的对象锁给剥夺，其他程序就无法再使用这个对象，例如消费者
                        list.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                // 唤醒当前线程，并开始生产
//                System.out.println(Thread.currentThread().getName());
                list.notify();
                for (int i = 0; i < MAX_COUNT; i++) {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd kk:mm ss");
                    list.add(sdf.format(new Date()));
                }
            }
        }
    }
}

class Consumer implements Runnable {
    /**
     * 仓库
     */
    private List list;
    /**
     * 最小长度
     */
    private final Integer MIN_COUNT = 0;

    public Consumer(List list) {
        this.list = list;
    }

    @Override
    public void run() {
        // 只要有数据，就无限消费
        while (true) {
            // 剥夺list对象的对象锁
            synchronized (list) {
                if (list.size() > 0) {
                    // 测试wait之后是否会再次抢锁
                    System.out.println("Consumer抢锁～");
                    // 唤醒当前消费线程
                    list.notify();
                    Iterator it = list.iterator();
                    while (it.hasNext()) {
                        it.next();
//                        System.out.println();
//                        System.out.println(Thread.currentThread().getName());
                        // 开始消费
                        it.remove();
                    }
                } else {
                    // 将剥夺的对象所释放
                    try {
                        list.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }
}