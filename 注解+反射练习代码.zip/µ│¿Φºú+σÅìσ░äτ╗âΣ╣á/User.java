/*
 * @Author: UpYou
 * @Date: 2020-11-09 18:03:29
 * @LastEditTime: 2020-11-09 18:34:33
 * @Description: 
 * 
 */
package annotation;
@Id(fiel = "id", type = int.class)
public class User {
    public int id;
}