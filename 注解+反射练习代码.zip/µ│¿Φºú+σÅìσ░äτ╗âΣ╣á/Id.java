/*
 * @Author: UpYou
 * @Date: 2020-11-09 17:54:54
 * @LastEditTime: 2020-11-09 18:06:30
 * @Description: 
 * 
 */
package annotation;
import java.lang.annotation.Target;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
public @interface Id {
    // 必须出现的字段
    String fiel();
    // 字段类型
    Class type();
}