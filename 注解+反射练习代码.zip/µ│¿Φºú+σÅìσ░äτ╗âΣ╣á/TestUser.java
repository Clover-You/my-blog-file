/*
 * @Author: UpYou
 * @Date: 2020-11-09 18:10:17
 * @LastEditTime: 2020-11-09 18:29:56
 * @Description: 
 * 
 */
package annotation;
import java.lang.reflect.Field;

public class TestUser {
    public static void main(String[] args) throws Exception{
        // 拿到User类
        Class userClass = Class.forName("annotation.User");
        // 判断这个类是否存在这个注解
        boolean userClassIsAnnotationPresent = userClass.isAnnotationPresent(Id.class);
        // 存在这个注解时执行对应操作
        if (userClassIsAnnotationPresent) {
            // 拿到这个类上Id注解标注必须出现的field
            Id idAnnotation = (Id) userClass.getDeclaredAnnotation(Id.class);
            // 拿到指定的属性跟属性类型
            String idFieldName = idAnnotation.fiel();
            Class idFieldType = idAnnotation.type();
            // 判断这个属性是否存在
            try {
                Field idField = userClass.getDeclaredField(idFieldName);
                // 判断这个属性类型是否对应
                if (idField.getType() != idFieldType) {
                    System.out.println("期望的属性类型为" + idFieldType.getSimpleName() + "; 可得到的类型为" + idField.getType().getSimpleName());
                }
            } catch (NoSuchFieldException | SecurityException e) {
                System.out.println("错误，不存在属性: " + idFieldName);
            }
        }
    }
}